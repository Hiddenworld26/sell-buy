const express = require("express");
const app = express();
const cors = require("cors");
const multer = require("multer");
const cloudinary = require("cloudinary").v2;
const conf = require("./conf/conf");
const fs = require("fs");
const mongoose = require("mongoose");
const book = require("./models/book");
const Cart = require("./models/cart");
const buyBook = require("./models/BuyBooks");
const bookRoutes = require('./routes/bookRoutes');
const user = require("./models/userModel");
require("./db/connectToDb");

//cloudinary
cloudinary.config({
  cloud_name: conf.cloudName,
  api_key: conf.apiKey,
  api_secret: conf.apiSecret,
});

app.use(cors());
app.use(express.json());

// app.get("/", (req, res) => {
//   res.send("server is working perfectly fine");
// });

app.use('/api/books', bookRoutes);

app.get('/api/books/:id', async (req, res) => {
  try {
    const book = await buyBook.findById(req.params.id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.json(book);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


//multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    return cb(null, "./uploads");
  },
  filename: (req, file, cb) => {
    return cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ storage });

//file upload
app.post("/uploads", upload.array("file", 10), async (req, res) => {
  console.log("");
  console.log("req.body hai bro");
  console.log(req.body);
  console.log(JSON.parse(req.body.bookDetails));
  // console.log(name, email);

  const {
    name,
    address,
    author,
    language,
    publisher,
    publicationDate,
    mrp,
    retailPrice,
    discountedPrice,
  } = JSON.parse(req.body.bookDetails);

  const images = req.files;
  console.log("images waala log");
  console.log(images);
  const imageUrls = [];

  for (const image of images) {
    const result = await cloudinary.uploader.upload(image.path).catch((err) => {
      console.log("cloudinary upload mein error".toUpperCase());
    });
    fs.unlink(image.path, (err) => {
      if (err) console.log(err);
      else {
        console.log("\nDeleted file: example_file.txt");
      }
    });
    imageUrls.push(result.secure_url);
  }

  console.log(imageUrls);

  await book.create({
    coverUrls: imageUrls,
    name,
    address,
    author,
    language,
    publisher,
    publicationDate,
    mrp,
    retailPrice,
    discountedPrice,
  });

  res.status(200).json({
    success: true,
    message: "BOOK added successfully",
    imageUrls,
  });
});

//adding books in cart
app.post('/cart/add', async (req, res) => {
  const { bookId, quantity } = req.body;

  if (!mongoose.Types.ObjectId.isValid(bookId)) {
    return res.status(400).json({ message: 'Invalid book ID' });
  }

  try {
   
    let cart = await Cart.findOne();
    
    if (!cart) {
      cart = new Cart({ books: [] });
    }


    const existingBookIndex = cart.books.findIndex(item => item.book.toString() === bookId);

    if (existingBookIndex > -1) {
      
      cart.books[existingBookIndex].quantity += quantity;
    } else {
     
      cart.books.push({ book: bookId, quantity });
    }

    await cart.save();
    res.status(200).json({ message: 'Book added to cart successfully', cart });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});



//getting cart items

app.get('/cart', async (req, res) => {
  try {
    
    const cart = await Cart.findOne().populate('books');

    if (!cart) {
      return res.status(404).json({ message: 'Cart not found' });
    }

    res.status(200).json(cart);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});



app.get("/buyBooks", async (req, res) => {
  const books = await book.find({});
  res.send(books);
});

app.listen(8080, () => {
  console.log("server is running on port 8080");
});